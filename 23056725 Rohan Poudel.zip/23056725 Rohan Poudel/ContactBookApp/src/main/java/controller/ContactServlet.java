package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Contact;
import model.ContactDAO;

import java.io.IOException;
import java.util.List;

@WebServlet("/ContactServlet")
public class ContactServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ContactDAO contactDAO;

    public void init() {
        contactDAO = new ContactDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "new":
                request.getRequestDispatcher("/view/add-contact.jsp").forward(request, response);
                break;
            case "edit":
                int id = Integer.parseInt(request.getParameter("id"));
                Contact contact = contactDAO.getContactById(id); // Fetch contact by ID
                if (contact != null) {
                    request.setAttribute("contact", contact);
                    request.getRequestDispatcher("/view/edit-contact.jsp").forward(request, response); // Forward to edit page
                } else {
                    response.sendRedirect(request.getContextPath() + "/ContactServlet?action=list"); // Redirect if not found
                }
                break;
            case "delete":
                id = Integer.parseInt(request.getParameter("id"));
                contactDAO.deleteContact(id);
                response.sendRedirect(request.getContextPath() + "/ContactServlet?action=list");
                break;
            default:
                List<Contact> contacts = contactDAO.getAllContacts();
                request.setAttribute("contactList", contacts);
                request.getRequestDispatcher("/view/contact-list.jsp").forward(request, response);
                break;
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            // Retrieve form data and create a contact
            Contact contact = new Contact();
            contact.setName(request.getParameter("name"));
            contact.setPhone(request.getParameter("phone"));
            contact.setEmail(request.getParameter("email"));
            contact.setAddress(request.getParameter("address"));

            contactDAO.addContact(contact);
            response.sendRedirect(request.getContextPath() + "/ContactServlet?action=list"); // Redirect to list after adding
        } else if ("update".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String address = request.getParameter("address");

            Contact contact = new Contact(id, name, phone, email, address);
            contactDAO.updateContact(contact);

            response.sendRedirect(request.getContextPath() + "/ContactServlet?action=list"); // Redirect to list after updating
        }
    }
}
